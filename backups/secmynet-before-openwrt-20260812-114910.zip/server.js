require('dotenv').config();

const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const helmet = require('helmet');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const path = require('node:path');

const { initDb, run, all, get, makeId } = require('./db');

const app = express();
const PORT = process.env.PORT || 3000;
const HOST = process.env.SERVER_HOST || '0.0.0.0';
const JWT_SECRET = process.env.JWT_SECRET || 'secmynet-prod-secret';

app.use(helmet());
app.use(cors());
app.use(compression());
app.use(morgan('tiny'));
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(__dirname, 'static')));
app.use(
  rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 200,
    standardHeaders: true,
    legacyHeaders: false
  })
);

async function ensureDb() {
  await initDb();
}

async function createAdminSeed() {
  await ensureDb();
  const passwordHash = await bcrypt.hash('Admin@123', 10);
  await run(
    `INSERT OR IGNORE INTO users (id, name, email, password_hash, role, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    ['admin-1', 'SecMyNet Admin', 'admin@secmynet.com', passwordHash, 'admin', new Date().toISOString()]
  );
}

function createToken(user) {
  return jwt.sign({ id: user.id, email: user.email, role: user.role }, JWT_SECRET, { expiresIn: '12h' });
}

function sanitizeUser(user) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    accessStatus: user.access_status || 'enabled',
    createdAt: user.created_at || user.createdAt
  };
}

function authRequired(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    return res.status(401).json({ message: 'Authentication token is required.' });
  }

  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.user = payload;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
}

function adminRequired(req, res, next) {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin rights are required for this action.' });
  }
  next();
}

function parseAllowedUsers(rawAllowedIds) {
  try {
    return JSON.parse(rawAllowedIds || '[]');
  } catch (error) {
    return [];
  }
}

async function createNotification({ type, message, userId = null, deviceId = null, locationId = null }) {
  await run(
    `INSERT INTO notifications (id, type, message, user_id, device_id, location_id, status, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
    [makeId('notification'), type, message, userId, deviceId, locationId, 'unread']
  );
}

app.get('/api/health', async (_req, res) => {
  await ensureDb();
  res.json({ status: 'ok', message: 'SecMyNet portal API is running' });
});

app.post('/api/register', async (req, res) => {
  await ensureDb();
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ message: 'name, email, and password are required.' });
  }

  const duplicate = await get('SELECT id FROM users WHERE LOWER(email) = LOWER($1)', [email]);
  if (duplicate) {
    return res.status(409).json({ message: 'A user with that email already exists.' });
  }

  const userId = makeId('user');
  const passwordHash = await bcrypt.hash(password, 12);

  await run(
    `INSERT INTO users (id, name, email, password_hash, role, created_at)
     VALUES ($1, $2, $3, $4, $5, NOW())`,
    [userId, name, email, passwordHash, 'user']
  );

  const user = await get('SELECT * FROM users WHERE id = $1', [userId]);
  res.status(201).json({
    message: 'Registration successful.',
    token: createToken(user),
    user: sanitizeUser(user)
  });
});

app.post('/api/login', async (req, res) => {
  await ensureDb();
  const { email, password } = req.body;
  const user = await get('SELECT * FROM users WHERE LOWER(email) = LOWER($1)', [email]);

  if (!user) {
    return res.status(401).json({ message: 'Invalid email or password.' });
  }

  const passwordMatches = await bcrypt.compare(password, user.password_hash);
  if (!passwordMatches) {
    return res.status(401).json({ message: 'Invalid email or password.' });
  }

  if (user.access_status === 'disabled') {
    return res.status(403).json({ message: 'This user account has been disabled. Contact your administrator.' });
  }

  res.json({
    message: 'Login successful.',
    token: createToken(user),
    user: sanitizeUser(user)
  });
});

app.get('/api/profile', authRequired, async (req, res) => {
  await ensureDb();
  const user = await get('SELECT * FROM users WHERE id = $1', [req.user.id]);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  res.json({ user: sanitizeUser(user) });
});

app.get('/api/dashboard', authRequired, adminRequired, async (req, res) => {
  await ensureDb();

  const users = await all('SELECT * FROM users ORDER BY created_at DESC');
  const locations = await all('SELECT * FROM locations ORDER BY created_at DESC');
  const devices = await all('SELECT * FROM devices ORDER BY created_at DESC');
  const connections = await all(`
    SELECT c.*, u.name AS user_name, u.email AS user_email, d.name AS device_name
    FROM connections c
    JOIN users u ON u.id = c.user_id
    JOIN devices d ON d.id = c.device_id
    ORDER BY c.connected_at DESC
  `);

  const totalUsers = await get('SELECT COUNT(*) AS total FROM users');
  const totalAdmins = await get('SELECT COUNT(*) AS total FROM users WHERE role = $1', ['admin']);
  const totalLocations = await get('SELECT COUNT(*) AS total FROM locations');
  const totalDevices = await get('SELECT COUNT(*) AS total FROM devices');
  const activeConnections = await get('SELECT COUNT(*) AS total FROM connections WHERE status = $1', ['connected']);

  const stats = {
    totalUsers: Number(totalUsers.total || 0),
    adminUsers: Number(totalAdmins.total || 0),
    totalLocations: Number(totalLocations.total || 0),
    totalDevices: Number(totalDevices.total || 0),
    activeConnections: Number(activeConnections.total || 0)
  };

  const enrichedLocations = await Promise.all(
    locations.map(async (location) => {
      const deviceCount = await get('SELECT COUNT(*) AS total FROM devices WHERE location_id = $1', [location.id]);
      return {
        ...location,
        devicesCount: Number(deviceCount.total || 0)
      };
    })
  );

  const enrichedDevices = await Promise.all(
    devices.map(async (device) => {
      const location = locations.find((item) => item.id === device.location_id) || null;
      const allowedUserIds = parseAllowedUsers(device.allowed_user_ids);
      const allowedUsers = users
        .filter((user) => allowedUserIds.includes(user.id))
        .map(sanitizeUser);

      return {
        ...device,
        allowedUserIds,
        location,
        allowedUsers
      };
    })
  );

  const dashboardConnections = connections.map((connection) => ({
    ...connection,
    dataUsedMb: Number(connection.data_used_mb || 0),
    userName: connection.user_name,
    userEmail: connection.user_email,
    deviceName: connection.device_name,
    connectedAt: connection.connected_at,
    disconnectedAt: connection.disconnected_at
  }));

  const adminUser = await get('SELECT * FROM users WHERE id = $1', [req.user.id]);

  res.json({
    admin: sanitizeUser(adminUser),
    stats,
    locations: enrichedLocations,
    devices: enrichedDevices,
    connections: dashboardConnections,
    users: users.map(sanitizeUser)
  });
});

app.get('/api/user-dashboard', authRequired, async (req, res) => {
  await ensureDb();

  const user = await get('SELECT * FROM users WHERE id = $1', [req.user.id]);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  const devices = await all('SELECT * FROM devices ORDER BY created_at DESC');
  const locations = await all('SELECT * FROM locations ORDER BY created_at DESC');
  const connections = await all(`
    SELECT c.*, d.name AS device_name, l.name AS location_name
    FROM connections c
    JOIN devices d ON d.id = c.device_id
    JOIN locations l ON l.id = d.location_id
    WHERE c.user_id = $1
    ORDER BY c.connected_at DESC
  `, [req.user.id]);

  const allowedDevices = devices.filter((device) => parseAllowedUsers(device.allowed_user_ids).includes(req.user.id));
  const activeConnections = connections.filter((connection) => connection.status === 'connected');

  const dashboardConnections = connections.map((connection) => ({
    ...connection,
    dataUsedMb: Number(connection.data_used_mb || 0),
    deviceName: connection.device_name,
    locationName: connection.location_name,
    connectedAt: connection.connected_at,
    disconnectedAt: connection.disconnected_at
  }));

  res.json({
    ok: true,
    user: sanitizeUser(user),
    stats: {
      totalConnections: Number(connections.length || 0),
      totalDevices: Number(allowedDevices.length || 0),
      activeConnections: Number(activeConnections.length || 0)
    },
    devices: allowedDevices.map((device) => ({
      ...device,
      allowedUserIds: parseAllowedUsers(device.allowed_user_ids),
      location: locations.find((location) => location.id === device.location_id) || null
    })),
    connections: dashboardConnections,
    locations
  });
});

app.post('/api/locations', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { name, city } = req.body;

  if (!name || !city) {
    return res.status(400).json({ message: 'name and city are required.' });
  }

  const locationId = makeId('location');
  await run(
    `INSERT INTO locations (id, name, city, admin_id, created_at)
     VALUES ($1, $2, $3, $4, NOW())`,
    [locationId, name, city, req.user.id]
  );

  const location = await get('SELECT * FROM locations WHERE id = $1', [locationId]);
  res.status(201).json({ message: 'Location added.', location });
});

app.get('/api/notifications', authRequired, adminRequired, async (_req, res) => {
  await ensureDb();
  const notifications = await all(`
    SELECT n.*, u.name AS user_name, u.email AS user_email, d.name AS device_name, l.name AS location_name
    FROM notifications n
    LEFT JOIN users u ON u.id = n.user_id
    LEFT JOIN devices d ON d.id = n.device_id
    LEFT JOIN locations l ON l.id = n.location_id
    ORDER BY n.created_at DESC
  `);
  res.json({ notifications });
});

app.post('/api/notifications/:notificationId/respond', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { allow, action } = req.body;
  const notification = await get('SELECT * FROM notifications WHERE id = $1', [req.params.notificationId]);
  if (!notification || notification.status !== 'unread') {
    return res.status(404).json({ message: 'Pending connection request not found.' });
  }

  if (notification.type === 'connection_request' && (allow || action === 'allow')) {
    const device = await get('SELECT * FROM devices WHERE id = $1', [notification.device_id]);
    const allowedUsers = parseAllowedUsers(device.allowed_user_ids);
    if (!allowedUsers.includes(notification.user_id)) allowedUsers.push(notification.user_id);
    await run('UPDATE devices SET allowed_user_ids = $1 WHERE id = $2', [JSON.stringify(allowedUsers), device.id]);
    await run(
      `INSERT INTO connections (id, device_id, user_id, status, data_used_mb, connected_at, disconnected_at)
       VALUES ($1, $2, $3, $4, $5, NOW(), NULL)`,
      [makeId('connection'), device.id, notification.user_id, 'connected', 0]
    );
  }
  if (notification.type === 'connection_request') {
    const approved = allow || action === 'allow';
    await run('UPDATE notifications SET status = $1 WHERE id = $2', [approved ? 'allowed' : 'denied', notification.id]);
    return res.json({ message: approved ? 'User allowed and connected.' : 'Connection request denied.' });
  }

  if (notification.type === 'overconsumption') {
    if (action === 'disconnect') {
      await run(
        "UPDATE connections SET status = 'disconnected', disconnected_at = NOW() WHERE user_id = $1 AND device_id = $2 AND status = 'connected'",
        [notification.user_id, notification.device_id]
      );
      await run('UPDATE notifications SET status = $1 WHERE id = $2', ['disconnected', notification.id]);
      return res.json({ message: 'User disconnected due to data usage.' });
    }
    await run('UPDATE notifications SET status = $1 WHERE id = $2', ['allowed', notification.id]);
    return res.json({ message: 'User is allowed to continue using data.' });
  }

  return res.status(400).json({ message: 'Unsupported notification action.' });
});

app.patch('/api/locations/:locationId', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { name, city } = req.body;

  if (!name || !city) {
    return res.status(400).json({ message: 'name and city are required.' });
  }

  const existing = await get('SELECT * FROM locations WHERE id = $1', [req.params.locationId]);
  if (!existing) {
    return res.status(404).json({ message: 'Location not found.' });
  }

  await run('UPDATE locations SET name = $1, city = $2 WHERE id = $3', [name, city, existing.id]);
  const location = await get('SELECT * FROM locations WHERE id = $1', [existing.id]);
  res.json({ message: 'Location updated.', location });
});

app.post('/api/devices', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { locationId, name, wifiName, status } = req.body;

  if (!locationId || !name || !wifiName) {
    return res.status(400).json({ message: 'locationId, name, and wifiName are required.' });
  }

  const deviceId = makeId('device');
  await run(
    `INSERT INTO devices (id, location_id, name, wifi_name, status, allowed_user_ids, created_by, created_at)
     VALUES ($1, $2, $3, $4, $5, $6, $7, NOW())`,
    [deviceId, locationId, name, wifiName, status || 'allowed', '[]', req.user.id]
  );

  const device = await get('SELECT * FROM devices WHERE id = $1', [deviceId]);
  const location = await get('SELECT * FROM locations WHERE id = $1', [device.location_id]);
  const payload = {
    ...device,
    location,
    allowedUserIds: parseAllowedUsers(device.allowed_user_ids),
    allowedUsers: []
  };

  res.status(201).json({ message: 'Device added.', device: payload });
});

app.post('/api/devices/:deviceId/allow-user', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { userId } = req.body;
  const device = await get('SELECT * FROM devices WHERE id = $1', [req.params.deviceId]);

  if (!device) {
    return res.status(404).json({ message: 'Device not found.' });
  }

  const user = await get('SELECT * FROM users WHERE id = $1', [userId]);
  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  const allowedUsers = parseAllowedUsers(device.allowed_user_ids);
  if (!allowedUsers.includes(userId)) {
    allowedUsers.push(userId);
  }

  await run('UPDATE devices SET allowed_user_ids = $1 WHERE id = $2', [JSON.stringify(allowedUsers), device.id]);
  const updatedDevice = await get('SELECT * FROM devices WHERE id = $1', [device.id]);

  res.json({
    message: 'User allowed to connect to the device.',
    device: {
      ...updatedDevice,
      allowedUserIds: parseAllowedUsers(updatedDevice.allowed_user_ids)
    }
  });
});

app.post('/api/devices/:deviceId/disallow-user', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { userId } = req.body;
  const device = await get('SELECT * FROM devices WHERE id = $1', [req.params.deviceId]);

  if (!device) {
    return res.status(404).json({ message: 'Device not found.' });
  }

  const allowedUsers = parseAllowedUsers(device.allowed_user_ids).filter((id) => id !== userId);
  await run('UPDATE devices SET allowed_user_ids = $1 WHERE id = $2', [JSON.stringify(allowedUsers), device.id]);
  await run(`UPDATE connections SET status = 'blocked' WHERE device_id = $1 AND user_id = $2`, [device.id, userId]);

  res.json({ message: 'User removed from the allowed list.', device: { ...device, allowedUserIds: allowedUsers } });
});

app.post('/api/devices/:deviceId/disconnect-user', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { userId } = req.body;
  const connection = await get(
    'SELECT * FROM connections WHERE device_id = $1 AND user_id = $2 AND status = $3',
    [req.params.deviceId, userId, 'connected']
  );

  if (!connection) {
    return res.status(404).json({ message: 'No active connection found for that user on this device.' });
  }

  await run(
    'UPDATE connections SET status = $1, disconnected_at = NOW() WHERE id = $2',
    ['disconnected', connection.id]
  );

  res.json({ message: 'User disconnected from the device.', connection: { ...connection, status: 'disconnected' } });
});

// A restart request is recorded as an admin action. Actual router integration can
// be attached here when managed device APIs are available.
app.post('/api/devices/:deviceId/restart', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const device = await get('SELECT * FROM devices WHERE id = $1', [req.params.deviceId]);

  if (!device) {
    return res.status(404).json({ message: 'Device not found.' });
  }

  res.json({ message: `Restart request sent to ${device.name}.`, deviceId: device.id });
});

app.post('/api/users/:userId/toggle-access', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const user = await get('SELECT * FROM users WHERE id = $1', [req.params.userId]);

  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }
  if (user.role === 'admin') {
    return res.status(400).json({ message: 'Administrator access cannot be disabled here.' });
  }

  const accessStatus = user.access_status === 'disabled' ? 'enabled' : 'disabled';
  await run('UPDATE users SET access_status = $1 WHERE id = $2', [accessStatus, user.id]);
  if (accessStatus === 'disabled') {
    await run("UPDATE connections SET status = 'disconnected', disconnected_at = NOW() WHERE user_id = $1 AND status = 'connected'", [user.id]);
  }

  res.json({ message: `User ${accessStatus}.`, user: { ...sanitizeUser(user), accessStatus } });
});

app.post('/api/connections/request', authRequired, async (req, res) => {
  await ensureDb();
  const { deviceId, userId } = req.body;
  const device = await get('SELECT * FROM devices WHERE id = $1', [deviceId]);
  const user = await get('SELECT * FROM users WHERE id = $1', [userId]);

  if (!device) {
    return res.status(404).json({ message: 'Device not found.' });
  }

  if (!user) {
    return res.status(404).json({ message: 'User not found.' });
  }

  if (user.access_status === 'disabled') {
    return res.status(403).json({ message: 'This user account is disabled.' });
  }

  if (!parseAllowedUsers(device.allowed_user_ids).includes(userId)) {
    const existingRequest = await get(
      "SELECT id FROM notifications WHERE type = 'connection_request' AND user_id = $1 AND device_id = $2 AND status = 'unread'",
      [userId, device.id]
    );
    if (!existingRequest) {
      await createNotification({
        type: 'connection_request',
        message: `${user.name} requested access to ${device.name}.`,
        userId,
        deviceId: device.id,
        locationId: device.location_id
      });
    }
    return res.status(202).json({ message: 'Connection request sent to the administrator for approval.' });
  }

  const existingConnection = await get(
    'SELECT * FROM connections WHERE device_id = $1 AND user_id = $2 AND status = $3',
    [deviceId, userId, 'connected']
  );

  if (existingConnection) {
    await run('UPDATE connections SET status = $1 WHERE id = $2', ['connected', existingConnection.id]);
    res.status(201).json({ message: 'Connection allowed.', connection: { ...existingConnection, status: 'connected' } });
    return;
  }

  const connectionId = makeId('connection');
  await run(
    `INSERT INTO connections (id, device_id, user_id, status, data_used_mb, connected_at, disconnected_at)
     VALUES ($1, $2, $3, $4, $5, NOW(), NULL)`,
    [connectionId, deviceId, userId, 'connected', 0]
  );

  const connection = await get('SELECT * FROM connections WHERE id = $1', [connectionId]);
  res.status(201).json({ message: 'Connection allowed.', connection });
});

app.post('/api/connections/:connectionId/usage', authRequired, adminRequired, async (req, res) => {
  await ensureDb();
  const { dataUsedMb } = req.body;
  const connection = await get('SELECT * FROM connections WHERE id = $1', [req.params.connectionId]);

  if (!connection) {
    return res.status(404).json({ message: 'Connection not found.' });
  }

  const nextUsage = Number(connection.data_used_mb || 0) + Number(dataUsedMb || 0);
  await run('UPDATE connections SET data_used_mb = $1 WHERE id = $2', [nextUsage, connection.id]);

  const crossedThresholds = [1024, 2048, 3072].filter((threshold) => Number(connection.data_used_mb || 0) < threshold && nextUsage >= threshold);
  if (crossedThresholds.length) {
    const user = await get('SELECT * FROM users WHERE id = $1', [connection.user_id]);
    const device = await get('SELECT * FROM devices WHERE id = $1', [connection.device_id]);
    await Promise.all(crossedThresholds.map((threshold) => createNotification({
      type: 'overconsumption',
      message: `${user.name} exceeded ${threshold / 1024} GB of data usage on ${device.name}.`,
      userId: user.id,
      deviceId: device.id,
      locationId: device.location_id
    })));
  }

  res.json({ message: 'Usage updated.', connection: { ...connection, dataUsedMb: nextUsage } });
});

app.use((_req, res) => {
  res.status(404).json({ message: 'Route not found.' });
});

if (require.main === module) {
  ensureDb()
    .then(createAdminSeed)
    .then(() => {
      app.listen(PORT, HOST, () => {
        console.log(`SecMyNet API listening on ${HOST}:${PORT}`);
      });
    })
    .catch((error) => {
      console.error('Unable to start server', error);
      process.exit(1);
    });
}

module.exports = app;
